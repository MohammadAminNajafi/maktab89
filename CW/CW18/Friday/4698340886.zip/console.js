function Geeks1() {
    document.getElementById("row1").remove();
}
function Geeks2() {
    document.getElementById("row2").remove();
}
function Geeks3() {
    document.getElementById("row3").remove();
}